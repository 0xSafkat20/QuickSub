import { readFile, writeFile } from 'node:fs/promises';
import ts from 'typescript';

async function readData(name) {
  const source = await readFile(new URL(`../src/data/${name}.ts`, import.meta.url), 'utf8');
  const { outputText } = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.ES2022, target: ts.ScriptTarget.ES2022 },
  });
  return import(`data:text/javascript;base64,${Buffer.from(outputText).toString('base64')}`);
}
const { products } = await readData('products');
const { faqItems } = await readData('faq');
const { legalDocuments } = await readData('legal');
const knowledge = {
  products: products.map(p => ({
    id: p.id, name: p.name, category: p.category,
    description: p.shortDescription, details: p.cardCopy,
    startingPrice: p.startingPrice, deliveryEstimate: p.deliveryEstimate,
    popularPlan: p.popularPlan, inStock: !p.outOfStock,
  })),
  // Other FAQ entries describe checkout/account features that are not implemented.
  faq: faqItems.filter(p => ['1', '6', '7'].includes(p.id)),
  policies: Object.fromEntries(['Refund Policy', 'Terms and Conditions', 'Disclaimer'].map(key => [key, legalDocuments[key]])),
  operations: {
    ordering: 'Orders, exact package pricing, payment instructions and activation help are handled by human support on WhatsApp.',
    supportHours: '10 AM–11 PM Bangladesh time (UTC+6)',
    limitations: 'No live order database, payment verification, account login, checkout or automatic activation is connected. Order tracking on the website is demonstration data only. Never report a real order status.',
  },
};
await writeFile(new URL('../server/knowledge.json', import.meta.url), JSON.stringify(knowledge, null, 2) + '\n');
console.log(`Chat knowledge updated: ${products.length} products.`);
