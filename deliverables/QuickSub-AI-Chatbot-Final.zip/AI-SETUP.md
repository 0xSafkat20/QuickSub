# QuickSub AI support

The existing chat design is preserved. Messages and quick replies now use the Express `/api/chat` endpoint. The assistant supports English, Bangla and Banglish, asks about needs and budget, recommends catalog products, answers store questions and offers the existing WhatsApp handoff.

## Run locally

Use Node.js 22.18 or later.

1. Run `npm ci` in the project folder, then `npm ci --prefix server`.
2. Copy `server/.env.example` to `server/.env`.
3. Set `OPENAI_API_KEY` in that private file to your OpenAI API key. Configure billing/API access in your OpenAI account. Never put this key in a `VITE_` variable, browser code, screenshots or chat messages.
4. Run `npm run build`, then `npm start`.
5. Open `http://localhost:4000`. This serves the production website and backend together.

For development, run `npm start` and `npm run dev` in separate terminals. Vite proxies `/api` and `/buy` to port 4000. Keep `PORT=4000` for development unless you also update the Vite proxy.

## Deployment

Deploy the complete Node project, not just `dist`. Install both root and server dependencies, run `npm run build`, and start with `npm start`. Set `OPENAI_API_KEY` privately in the hosting environment and set `PUBLIC_ORIGIN` to your exact HTTPS website origin (without a trailing slash). The server serves only `dist`; private server files are not public assets.

Behind a reverse proxy, configure `TRUST_PROXY_HOPS` for the exact number of trusted proxies, and block direct public access to the backend port. Do not guess this setting: it controls the client address used by the chat rate limiter. The default does not trust forwarded headers. A separate static frontend must route `/api/*` and `/buy` to this server on the same public origin.

Default model: `gpt-4.1-mini`, configurable through `OPENAI_MODEL`. The implementation uses the OpenAI Responses API with structured outputs and `store: false`:
- https://developers.openai.com/api/docs/guides/structured-outputs
- https://developers.openai.com/api/docs/models/gpt-4.1-mini

## Website knowledge

`npm run knowledge` generates `server/knowledge.json` directly from `src/data/products.ts`, selected implemented FAQs and store policies. This runs automatically before development and production builds. Restart the backend after updating knowledge. Product data is loaded once, not fetched on every message. No vector database or AI browser bundle is needed.

Existing FAQ statements about accounts, checkout and real order tracking are excluded because those systems are not implemented. Exact package-duration pricing is not present in the catalog: the assistant is instructed to label prices as starting prices and ask human support to confirm details. It must not promise discounts, verify payment or invent tracking results. Recommendations are validated against known in-stock product IDs. AI-generated wording still needs business review; prompts cannot guarantee perfect factual answers.

## Privacy, reliability and cost

- Chat starts only when a customer sends a message. The greeting identifies AI and discloses provider processing. Do not request credentials or payment secrets.
- Conversation history is kept in server memory, capped at 12 messages, and expires after 30 minutes of inactivity. Expired entries are removed on the next chat request. Browser chat history stays in memory only. No chat logging or database is added.
- `store: false` disables stored Responses objects; it does not replace the provider's data-retention policies. Review provider terms before launch.
- Limits: 1,500 characters per message, 16 KB request body, 15 requests/minute per IP, 120/minute globally, 8 concurrent requests, 1,000 sessions, 600 output tokens and a 20-second provider timeout. No automatic paid retries.
- Configure an OpenAI project spending limit/alerts before launch. In-memory limits and sessions are for a single server instance; use a shared limiter/session store or sticky sessions when scaling to multiple processes.
- Missing keys, blocked requests, timeouts and provider errors produce an honest catalog/help fallback and WhatsApp link. This fallback is not a live AI conversation.

## Verification

Run `npm run typecheck`, `npm run lint`, `npm run build`, `npm run test:chat`, and `node scripts/check-chat.mjs`. Browser tests require Chrome; set `CHROME_PATH` if needed. `node scripts/check-privacy.mjs` tests blocked storage and external requests.

Automated provider tests use simulated responses and make no paid API calls. A real-key smoke test remains necessary: ask for a study recommendation under ৳500, follow up about duration, ask in Bangla, ask about an unavailable product, and ask to track an order. Confirm the assistant asks useful questions, labels starting prices, and hands off unsupported actions instead of inventing results.
